#' 『吾輩は猫である』の冒頭部分
#'
#' 『吾輩は猫である』の冒頭部分
#'
#' @format Tibble
#' \describe{
#'   \item{text}{本文}
#' }
"neko"
